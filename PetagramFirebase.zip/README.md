# Petagram-Firebase (Android + Backend)

Proyecto basado en Petagram que integra Firebase Cloud Messaging (FCM) en Android (Java)
y un Web Service en Java (Spring Boot) desplegable en Heroku que expone el endpoint
`/registrar-usuario` para almacenar tokens de dispositivo (id_dispositivo) y el id de usuario Instagram.

**Contenido del ZIP**
- app/ : Proyecto Android (Java) con integración a Firebase y opción "Recibir Notificaciones".
- backend/ : Spring Boot aplicación con endpoint `/registrar-usuario` y configuración para Heroku/Postgres.
- google-services.json : Archivo de configuración (dummy) para compilar el app; reemplázalo por el real.
- docs/Endpoint_Explicacion.pdf : Explicación del endpoint y la plataforma usada (texto simple).

**Instrucciones rápidas Android**
1. Abre `app/` en Android Studio (Import project (Gradle)).
2. Reemplaza `app/src/main/res/values/google_maps_api.xml` y `app/google-services.json` si necesitas tu propia clave de Maps/FCM.
3. Configura la URL del backend en `app/src/main/res/values/strings.xml` (valor `backend_url`).
4. Ejecuta en dispositivo/emulador con Google Play Services.

**Instrucciones rápidas Backend (Heroku)**
1. Desde `backend/` construye el jar (`./mvnw package`) y despliega a Heroku siguiendo su guía para Java apps.
2. Asegúrate de provisionar una base de datos PostgreSQL en Heroku. Heroku proporciona `DATABASE_URL` env var.
3. El endpoint POST `/registrar-usuario` acepta JSON con `id_dispositivo` y `id_usuario_instagram`.
