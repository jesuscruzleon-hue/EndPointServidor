package com.petagram;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AssignUserActivity extends AppCompatActivity {

    private static final String PREFS = "petagram_prefs";
    private static final String KEY_INSTAGRAM = "insta_id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assign_user);

        final EditText et = findViewById(R.id.et_instagram_id);
        Button btn = findViewById(R.id.btn_save_id);

        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        String cur = sp.getString(KEY_INSTAGRAM, null);
        if (cur != null) et.setText(cur);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = et.getText().toString().trim();
                if (id.isEmpty()) {
                    Toast.makeText(AssignUserActivity.this, "Ingrese un ID válido", Toast.LENGTH_SHORT).show();
                    return;
                }
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_INSTAGRAM, id).apply();
                Toast.makeText(AssignUserActivity.this, "ID guardado", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}
