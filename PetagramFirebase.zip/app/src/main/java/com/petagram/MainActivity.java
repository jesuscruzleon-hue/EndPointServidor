package com.petagram;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.messaging.FirebaseMessaging;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS = "petagram_prefs";
    private static final String KEY_TOKEN = "fcm_token";
    private static final String KEY_INSTAGRAM = "insta_id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnAssign = findViewById(R.id.btn_assign);
        Button btnRecibir = findViewById(R.id.btn_recibir);

        btnAssign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AssignUserActivity.class));
            }
        });

        btnRecibir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // get token and instagram id, then send to backend
                final SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
                final String instaId = sp.getString(KEY_INSTAGRAM, null);
                if (instaId == null) {
                    Toast.makeText(MainActivity.this, "Asigna primero un ID de Instagram (Configurar Cuenta)", Toast.LENGTH_LONG).show();
                    return;
                }

                // Fetch current FCM token (may be cached)
                FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        Toast.makeText(MainActivity.this, "No se pudo obtener token FCM", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    String token = task.getResult();
                    // Save token locally
                    sp.edit().putString(KEY_TOKEN, token).apply();

                    // Send to backend (network on background thread)
                    new Thread(() -> {
                        String backend = getString(R.string.backend_url);
                        String url = backend + "/registrar-usuario";
                        OkHttpClient client = new OkHttpClient();
                        MediaType JSON = MediaType.get("application/json; charset=utf-8");
                        String json = String.format("{\"id_dispositivo\":\"%s\",\"id_usuario_instagram\":\"%s\"}", token, instaId);
                        RequestBody body = RequestBody.create(json, JSON);
                        Request req = new Request.Builder().url(url).post(body).build();
                        try (Response resp = client.newCall(req).execute()) {
                            if (resp.isSuccessful()) {
                                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Registrado en servidor correctamente", Toast.LENGTH_LONG).show());
                            } else {
                                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Fallo al registrar: " + resp.code(), Toast.LENGTH_LONG).show());
                            }
                        } catch (IOException e) {
                            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Error de red: " + e.getMessage(), Toast.LENGTH_LONG).show());
                        }
                    }).start();
                });
            }
        });
    }
}
