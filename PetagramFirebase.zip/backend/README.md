# Petagram Backend


Este backend expone el endpoint POST /registrar-usuario


JSON esperado:


{
  "id_dispositivo": "<token_fcm>",
  "id_usuario_instagram": "<id_usuario>"
}


Para desplegar en Heroku:


1. Asegura que el pom y Java version sean compatibles con Heroku.
2. Crea la app en Heroku y añade el addon Heroku Postgres.
3. Heroku exportará la variable `DATABASE_URL` automáticamente. Puedes convertirla a JDBC URL en runtime si lo deseas.
4. Empuja el repo y Heroku debe detectar y construir la app.
