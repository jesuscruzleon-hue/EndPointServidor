package com.petagram.backend.controller;

import com.petagram.backend.model.UsuarioInst;
import com.petagram.backend.repo.UsuarioInstRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class RegistroController {

    private final UsuarioInstRepository repo;

    public RegistroController(UsuarioInstRepository repo) {
        this.repo = repo;
    }

    @PostMapping(path = "/registrar-usuario", consumes = "application/json")
    public ResponseEntity<?> registrar(@RequestBody UsuarioInst payload) {
        if (payload.getId_dispositivo() == null || payload.getId_dispositivo().isEmpty() ||
            payload.getId_usuario_instagram() == null || payload.getId_usuario_instagram().isEmpty()) {
            return ResponseEntity.badRequest().body("Campos requeridos: id_dispositivo, id_usuario_instagram");
        }
        UsuarioInst saved = repo.save(new UsuarioInst(payload.getId_dispositivo(), payload.getId_usuario_instagram()));
        return ResponseEntity.status(201).body(saved);
    }
}
