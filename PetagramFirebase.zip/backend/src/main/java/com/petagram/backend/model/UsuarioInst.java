package com.petagram.backend.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class UsuarioInst {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String id_dispositivo;
    private String id_usuario_instagram;

    public UsuarioInst() {}

    public UsuarioInst(String id_dispositivo, String id_usuario_instagram) {
        this.id_dispositivo = id_dispositivo;
        this.id_usuario_instagram = id_usuario_instagram;
    }

    // getters and setters
    public Long getId() { return id; }
    public String getId_dispositivo() { return id_dispositivo; }
    public void setId_dispositivo(String id_dispositivo) { this.id_dispositivo = id_dispositivo; }
    public String getId_usuario_instagram() { return id_usuario_instagram; }
    public void setId_usuario_instagram(String id_usuario_instagram) { this.id_usuario_instagram = id_usuario_instagram; }
}
