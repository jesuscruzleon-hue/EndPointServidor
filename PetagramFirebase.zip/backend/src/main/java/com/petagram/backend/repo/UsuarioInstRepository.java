package com.petagram.backend.repo;

import com.petagram.backend.model.UsuarioInst;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UsuarioInstRepository extends JpaRepository<UsuarioInst, Long> {
}
